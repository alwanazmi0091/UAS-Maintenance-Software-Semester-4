<?php
$koneksi = new mysqli ("localhost","root","","data_perpus");
?>