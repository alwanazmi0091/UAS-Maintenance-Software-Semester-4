# E-Library
Aplikasi Perpustakaan Berbasis Website

* Tampilan Login

Login dengan
username : admin
password : 123

![image](https://user-images.githubusercontent.com/70128349/224609996-27b04aa3-a9bd-4f7b-9dc7-097aff858b39.png)


* Tampilan Dashboard

 ![image](https://user-images.githubusercontent.com/70128349/224610261-0da4f00d-57a2-43f8-bbcd-d5c67b43b9ca.png)

 
* Tampilan Data Buku

![image](https://user-images.githubusercontent.com/70128349/224611064-dd975f59-8783-4f5d-ba20-7bff3a2a112c.png)
![image](https://user-images.githubusercontent.com/70128349/224611147-08ef3171-0481-4810-a3d7-6638112ccdcf.png)



* Tampilan Data Anggota

![image](https://user-images.githubusercontent.com/70128349/224611203-e79e5954-9e59-4447-953c-1fc5b6ad3eb7.png)
![image](https://user-images.githubusercontent.com/70128349/224611231-bd6ca70d-bd60-4383-aa47-7aad52cc87b8.png)
![image](https://user-images.githubusercontent.com/70128349/224611272-f6b8a004-6a7f-455b-99da-eec757090f18.png)
![image](https://user-images.githubusercontent.com/70128349/224611361-f3681ef2-2a83-4e9b-b79c-bf02f7c1f6d0.png)


* Tampilan Sirkulasi

![image](https://user-images.githubusercontent.com/70128349/224611440-718a7223-9c61-4e3a-983b-b68c0c1c46f5.png)


* Tampilan Laporan Sirkulasi

![image](https://user-images.githubusercontent.com/70128349/224611522-ec88068a-0dc8-4d3f-8485-a9e880036f2e.png)
![image](https://user-images.githubusercontent.com/70128349/224611568-c2124680-ff66-4358-971d-15ff7585e94c.png)
